/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","th",{
	"alt":"คำประกอบรูปภาพ",
	"lockRatio":"กำหนดอัตราส่วน กว้าง-สูง แบบคงที่",
	"vSpace":"ระยะแนวตั้ง",
	"hSpace":"ระยะแนวนอน",
	"border":"ขนาดขอบรูป"
});