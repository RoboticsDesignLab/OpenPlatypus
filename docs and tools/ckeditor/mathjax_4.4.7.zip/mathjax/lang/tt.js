/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'tt', {
	title: 'TeX\'та математика',
	button: 'Математика',
	dialogInput: 'Биредә TeX форматында аңлатмагызны языгыз',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX турыдна документлар',
	loading: 'йөкләнә...',
	pathName: 'математика'
} );
