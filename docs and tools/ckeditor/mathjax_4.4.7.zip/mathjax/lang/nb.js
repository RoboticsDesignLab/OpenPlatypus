/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'nb', {
	title: 'Matematikk i TeX',
	button: 'Matte',
	dialogInput: 'Skriv TeX-koden her',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX-dokumentasjon',
	loading: 'laster...',
	pathName: 'matte'
} );
